package com.example.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {
    String tag="Activity life cycle";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(tag,"In the onStart event");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(tag,"In the onStop event");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(tag,"In the Resume event");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(tag,"In the onRestart event");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(tag,"In the onDestroy event");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(tag,"In the onPause event");
    }
}