package com.example.expliciteintent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Activity2 extends AppCompatActivity {
    TextView tvWelcome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        tvWelcome= findViewById(R.id.tvWelcome);
        Intent intent=getIntent();

        String name =intent.getStringExtra("toActivity2");
        tvWelcome.setText(name+", welcome to Activity 2");
    }
}